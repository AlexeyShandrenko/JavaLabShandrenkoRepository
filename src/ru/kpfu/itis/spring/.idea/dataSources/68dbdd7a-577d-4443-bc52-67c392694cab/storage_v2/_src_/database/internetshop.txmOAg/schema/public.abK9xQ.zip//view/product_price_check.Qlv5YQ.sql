create view product_price_check(id, name, description, price) as
SELECT product.id,
       product.name,
       product.description,
       product.price
FROM product
WHERE product.price > 250
with local check option;

alter table product_price_check
    owner to postgres;

