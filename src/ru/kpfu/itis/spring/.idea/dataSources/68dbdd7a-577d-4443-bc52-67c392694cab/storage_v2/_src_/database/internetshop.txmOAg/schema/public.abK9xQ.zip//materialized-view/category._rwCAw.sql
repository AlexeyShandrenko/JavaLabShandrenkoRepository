create materialized view category as
SELECT product_category.id,
       product_category.category_name
FROM product_category;

alter materialized view category owner to postgres;

