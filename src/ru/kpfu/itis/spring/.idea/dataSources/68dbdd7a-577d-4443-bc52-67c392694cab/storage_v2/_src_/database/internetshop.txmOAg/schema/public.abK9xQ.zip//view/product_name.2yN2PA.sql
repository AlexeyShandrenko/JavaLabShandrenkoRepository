create view product_name(id, name, description, price) as
SELECT product.id,
       product.name,
       product.description,
       product.price
FROM product
WHERE product.description ~~ '%!%'::text;

alter table product_name
    owner to postgres;

